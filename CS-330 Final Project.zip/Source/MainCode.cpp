#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "SceneManager.h"
#include "ViewManager.h"
#include "camera.h"

GLuint compileShaders() {
    const char* vertexShaderSource = R"(
    #version 330 core
    layout(location = 0) in vec3 aPos;
    layout(location = 1) in vec3 aNormal;
    layout(location = 2) in vec2 aTexCoord;

    out vec3 FragPos;
    out vec3 Normal;
    out vec2 TexCoord;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main() {
        FragPos = vec3(model * vec4(aPos, 1.0));
        Normal = mat3(transpose(inverse(model))) * aNormal;  
        TexCoord = aTexCoord;

        gl_Position = projection * view * vec4(FragPos, 1.0);
    }
    )";

    const char* fragmentShaderSource = R"(
    #version 330 core
    struct Material {
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
        float shininess;
    };

    struct Light {
        vec3 position;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    in vec3 FragPos;
    in vec3 Normal;
    in vec2 TexCoord;

    out vec4 FragColor;

    uniform vec3 viewPos;
    uniform Material material;
    uniform Light light;
    uniform sampler2D texture1;

    void main() {
        // Ambient
        vec3 ambient = light.ambient * material.ambient;

        // Diffuse 
        vec3 norm = normalize(Normal);
        vec3 lightDir = normalize(light.position - FragPos);
        float diff = max(dot(norm, lightDir), 0.0);
        vec3 diffuse = light.diffuse * (diff * material.diffuse);

        // Specular
        vec3 viewDir = normalize(viewPos - FragPos);
        vec3 reflectDir = reflect(-lightDir, norm);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        vec3 specular = light.specular * (spec * material.specular);

        vec3 result = ambient + diffuse + specular;
        FragColor = texture(texture1, TexCoord) * vec4(result, 1.0);
    }
    )";

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);
    GLint success;
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetShaderInfoLog(vertexShader, 512, nullptr, infoLog);
        std::cerr << "Error" << infoLog << std::endl;
    }

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);
    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetShaderInfoLog(fragmentShader, 512, nullptr, infoLog);
        std::cerr << "Error" << infoLog << std::endl;
    }

    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        char infoLog[512];
        glGetProgramInfoLog(shaderProgram, 512, nullptr, infoLog);
        std::cerr << "Error" << infoLog << std::endl;
    }

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return shaderProgram;
}

Camera camera(glm::vec3(0.0f, 1.6f, -6.0f));
float deltaTime = 0.0f;
float lastFrame = 0.0f;
bool perspective = true;

void processInput(GLFWwindow* window) {
    float currentFrame = glfwGetTime();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        camera.ProcessKeyboard(UP, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        camera.ProcessKeyboard(DOWN, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        perspective = true;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        perspective = false;
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    static bool firstMouse = true;
    static float lastX = 800.0f / 2.0;
    static float lastY = 600.0f / 2.0;

    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;
    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
    camera.ProcessMouseScroll(yoffset);
}

int main() {
    if (!glfwInit()) {
        std::cerr << "Failed" << std::endl;
        return -1;
    }

    GLFWwindow* window = glfwCreateWindow(800, 600, "Basketball Court", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed" << std::endl;
        return -1;
    }

    GLuint shaderProgram = compileShaders();

    SceneManager sceneManager(shaderProgram);
    ViewManager viewManager;

    glEnable(GL_DEPTH_TEST);

    glm::mat2 texCoordTransform = glm::mat2(
        0.0f, 1.0f,  
        -1.0f, 0.0f    
    );

    struct Light {
        glm::vec3 position;
        glm::vec3 ambient;
        glm::vec3 diffuse;
        glm::vec3 specular;
    };

    Light light;
    light.position = glm::vec3(5.0f, 4.0f, 1.5f);
    light.ambient = glm::vec3(0.8f, 0.8f, 0.8f); 
    light.diffuse = glm::vec3(1.0f, 1.0f, 1.0f);
    light.specular= glm::vec3(1.0f, 1.0f, 1.0f);


    struct Material {
        glm::vec3 ambient;
        glm::vec3 diffuse;
        glm::vec3 specular;
        float shininess;
    };

    Material material;
    material.ambient = glm::vec3(1.0f, 1.0f, 1.0f);
    material.diffuse = glm::vec3(1.0f, 1.00f, 1.00f);
    material.specular = glm::vec3(1.0f, 1.0f, 1.0f);
    material.shininess = 35.0f;

    while (!glfwWindowShouldClose(window)) {
        processInput(window);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glUseProgram(shaderProgram);

        glm::mat4 view = camera.GetViewMatrix();
        glm::mat4 projection;
        if (perspective) {
            projection = glm::perspective(glm::radians(camera.Zoom), 800.0f / 600.0f, 0.1f, 100.0f);
        }
        else {
            projection = glm::ortho(-2.0f, 2.0f, -2.0f, 2.0f, 0.1f, 100.0f);
        }

        GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
        GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
        GLint projLoc = glGetUniformLocation(shaderProgram, "projection");
        GLint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");
        GLint lightPosLoc = glGetUniformLocation(shaderProgram, "light.position");
        GLint lightAmbientLoc = glGetUniformLocation(shaderProgram, "light.ambient");
        GLint lightDiffuseLoc = glGetUniformLocation(shaderProgram, "light.diffuse");
        GLint lightSpecularLoc = glGetUniformLocation(shaderProgram, "light.specular");
        GLint materialAmbientLoc = glGetUniformLocation(shaderProgram, "material.ambient");
        GLint materialDiffuseLoc = glGetUniformLocation(shaderProgram, "material.diffuse");
        GLint materialSpecularLoc = glGetUniformLocation(shaderProgram, "material.specular");
        GLint materialShininessLoc = glGetUniformLocation(shaderProgram, "material.shininess");

        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
        glUniform3fv(viewPosLoc, 1, glm::value_ptr(camera.Position));
        glUniform3fv(lightPosLoc, 1, glm::value_ptr(light.position));
        glUniform3fv(lightAmbientLoc, 1, glm::value_ptr(light.ambient));
        glUniform3fv(lightDiffuseLoc, 1, glm::value_ptr(light.diffuse));
        glUniform3fv(lightSpecularLoc, 1, glm::value_ptr(light.specular));
        glUniform3fv(materialAmbientLoc, 1, glm::value_ptr(material.ambient));
        glUniform3fv(materialDiffuseLoc, 1, glm::value_ptr(material.diffuse));
        glUniform3fv(materialSpecularLoc, 1, glm::value_ptr(material.specular));
        glUniform1f(materialShininessLoc, material.shininess);

        // ground plane
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderGroundPlane();

        // pole
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.7f, 3.6f));
        model = glm::scale(model, glm::vec3(1.0f, 0.75f, 1.0f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderCylinder();

        // backboard
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 1.8f, 3.52f));
        model = glm::scale(model, glm::vec3(1.0f, 1.0f, 0.5f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderBackboard();

        // rim
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 1.55f, 3.21f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::scale(model, glm::vec3(0.2f, 0.2f, 0.2f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderTorus();

        // net
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 1.095f, 3.53f));
        model = glm::scale(model, glm::vec3(1.8f, 1.35f, 1.6f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderNet();

        //three point line
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.001f, 3.0f)); 
        model = glm::scale(model, glm::vec3(2.29f, 0.05f, 1.6f));
        model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-350.0f, 0.0f, 0.0));
        model = glm::rotate(model, glm::radians(180.0f), glm::vec3(2.09f, 5.0f, 0.0f)); 
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderHalfTorus();

        // hoop box 
        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.001f, 2.51f));
        model = glm::scale(model, glm::vec3(3.0f, 0.005f, 2.7f)); 
        model = glm::rotate(model, glm::radians(180.0f), glm::vec3(2.09f, 0.0f, 0.0f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderHoopBox();

        model = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.001f, 2.51f));
        model = glm::scale(model, glm::vec3(3.0f, 0.005f, 2.7f));
        model = glm::rotate(model, glm::radians(180.0f), glm::vec3(2.09f, 0.0f, 2.1f));
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        sceneManager.renderHoopBox2();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
