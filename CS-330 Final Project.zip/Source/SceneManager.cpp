#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>
#include "SceneManager.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <iostream>

SceneManager::SceneManager(GLuint shaderProgram) : shaderProgram(shaderProgram) {
    groundTexture = loadTexture("..//../Utilities/textures/court.jpg");
    backboardTexture = loadTexture("..//../Utilities/textures/backboard.jpg");
    torusTexture = loadTexture("..//../Utilities/textures/abstract.jpg");
    cylinderTexture = loadTexture("..//../Utilities/textures/court.jpg");
    netTexture = loadTexture("..//../Utilities/textures/net.jpg");
    halfTorusTexture = loadTexture("..//../Utilities/textures/backboard.jpg");
    boxTexture = loadTexture("..//../Utilities/textures/backboard.jpg");

    createGroundPlane();
    createCylinder();
    createBackboard();
    createTorus();
    createNet();
    createHalfTorus();
    createHoopBox();
    createHoopBox2();
}

SceneManager::~SceneManager() {
    glDeleteVertexArrays(1, &groundVAO);
    glDeleteBuffers(1, &groundVBO);
    glDeleteBuffers(1, &groundEBO);
    glDeleteVertexArrays(1, &cylinderVAO);
    glDeleteBuffers(1, &cylinderVBO);
    glDeleteBuffers(1, &cylinderEBO);
    glDeleteVertexArrays(1, &backboardVAO);
    glDeleteBuffers(1, &backboardVBO);
    glDeleteBuffers(1, &backboardEBO);
    glDeleteVertexArrays(1, &torusVAO);
    glDeleteBuffers(1, &torusVBO);
    glDeleteBuffers(1, &torusEBO);
    glDeleteVertexArrays(1, &netVAO);
    glDeleteBuffers(1, &netVBO);
    glDeleteBuffers(1, &netEBO);
    glDeleteVertexArrays(1, &halfTorusVAO);
    glDeleteBuffers(1, &halfTorusVBO);
    glDeleteBuffers(1, &halfTorusEBO);
    glDeleteVertexArrays(1, &boxVAO);
    glDeleteBuffers(1, &boxVBO);
    glDeleteBuffers(1, &boxEBO);
    glDeleteTextures(1, &groundTexture);
    glDeleteTextures(1, &backboardTexture);
    glDeleteTextures(1, &torusTexture);
    glDeleteTextures(1, &cylinderTexture);
    glDeleteTextures(1, &netTexture);
    glDeleteTextures(1, &halfTorusTexture);
    glDeleteTextures(1, &boxTexture);
}

unsigned int SceneManager::loadTexture(const std::string& path) {
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path.c_str(), &width, &height, &nrComponents, 0);
    if (data) {
        GLenum format{};
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else {
        std::cerr << "Failed" << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}

void SceneManager::createGroundPlane() {
    float vertices[] = {
        -5.0f, 0.0f, -5.0f,  0.5f, 0.5f, 0.5f,  0.0f, 0.0f,
         5.0f, 0.0f, -5.0f,  0.5f, 0.5f, 0.5f,  1.0f, 0.0f,
         5.0f, 0.0f,  5.0f,  0.5f, 0.5f, 0.5f,  1.0f, 1.0f,
        -5.0f, 0.0f,  5.0f,  0.5f, 0.5f, 0.5f,  0.0f, 1.0f
    };
    unsigned int indices[] = {
        0, 1, 2,
        2, 3, 0
    };

    glGenVertexArrays(1, &groundVAO);
    glGenBuffers(1, &groundVBO);
    glGenBuffers(1, &groundEBO);

    glBindVertexArray(groundVAO);

    glBindBuffer(GL_ARRAY_BUFFER, groundVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, groundEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
}

void SceneManager::renderGroundPlane() {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, groundTexture);
    glBindVertexArray(groundVAO);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void SceneManager::createBackboard() {
    float vertices[] = {
        -0.5f,  0.6f,  0.0f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
         0.5f,  0.6f,  0.0f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
         0.5f, -0.5f,  0.0f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        -0.5f, -0.5f,  0.0f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,

        -0.5f,  0.6f, -0.1f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
         0.5f,  0.6f, -0.1f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
         0.5f, -0.5f, -0.1f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.1f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f
    };
    unsigned int indices[] = {
        0, 1, 2, 0, 2, 3,
        4, 5, 6, 4, 6, 7,
        0, 3, 7, 0, 7, 4,
        1, 2, 6, 1, 6, 5,
        0, 1, 5, 0, 5, 4,
        3, 2, 6, 3, 6, 7
    };

    glGenVertexArrays(1, &backboardVAO);
    glGenBuffers(1, &backboardVBO);
    glGenBuffers(1, &backboardEBO);

    glBindVertexArray(backboardVAO);

    glBindBuffer(GL_ARRAY_BUFFER, backboardVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, backboardEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
}

void SceneManager::renderBackboard() {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, backboardTexture);
    glBindVertexArray(backboardVAO);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void SceneManager::createCylinder() {
    float vertices[] = {
        0.1f, 1.0f,  0.1f,  1.0f, 0.5f, 0.0f,  0.0f, 0.0f,
        -0.1f, 1.0f,  0.1f,  1.0f, 0.5f, 0.0f,  1.0f, 0.0f,
        -0.1f, 1.0f, -0.1f,  1.0f, 0.5f, 0.0f,  1.0f, 1.0f,
         0.1f, 1.0f, -0.1f,  1.0f, 0.5f, 0.0f,  0.0f, 1.0f,
         0.1f, -1.0f,  0.1f,  1.0f, 0.5f, 0.0f,  0.0f, 0.0f,
        -0.1f, -1.0f,  0.1f,  1.0f, 0.5f, 0.0f,  1.0f, 0.0f,
        -0.1f, -1.0f, -0.1f,  1.0f, 0.5f, 0.0f,  1.0f, 1.0f,
         0.1f, -1.0f, -0.1f,  1.0f, 0.5f, 0.0f,  0.0f, 1.0f
    };
    unsigned int indices[] = {
        0, 1, 2, 2, 3, 0,
        4, 5, 6, 6, 7, 4,
        0, 1, 5, 5, 4, 0,
        1, 2, 6, 6, 5, 1,
        2, 3, 7, 7, 6, 2,
        3, 0, 4, 4, 7, 3
    };

    glGenVertexArrays(1, &cylinderVAO);
    glGenBuffers(1, &cylinderVBO);
    glGenBuffers(1, &cylinderEBO);

    glBindVertexArray(cylinderVAO);

    glBindBuffer(GL_ARRAY_BUFFER, cylinderVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, cylinderEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
}

void SceneManager::renderCylinder() {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, cylinderTexture);
    glBindVertexArray(cylinderVAO);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void SceneManager::createTorus() {
    const int majorSegments = 30;
    const int minorSegments = 30;
    const float majorRadius = 1.0f;
    const float minorRadius = 0.3f;

    std::vector<float> torusVertices;
    std::vector<unsigned int> torusIndices;

    for (int i = 0; i <= majorSegments; ++i) {
        for (int j = 0; j <= minorSegments; ++j) {
            float theta = 2.0f * glm::pi<float>() * float(i) / float(majorSegments);
            float phi = 2.0f * glm::pi<float>() * float(j) / float(minorSegments);

            float x = (majorRadius + minorRadius * cos(phi)) * cos(theta);
            float y = (majorRadius + minorRadius * cos(phi)) * sin(theta);
            float z = minorRadius * sin(phi);

            float u = (float)i / (float)majorSegments;
            float v = (float)j / (float)minorSegments;

            torusVertices.push_back(x);
            torusVertices.push_back(y);
            torusVertices.push_back(z);
            torusVertices.push_back(u);
            torusVertices.push_back(v);
        }
    }

    for (int i = 0; i < majorSegments; ++i) {
        for (int j = 0; j < minorSegments; ++j) {
            int first = (i * (minorSegments + 1)) + j;
            int second = first + minorSegments + 1;

            torusIndices.push_back(first);
            torusIndices.push_back(second);
            torusIndices.push_back(first + 1);

            torusIndices.push_back(second);
            torusIndices.push_back(second + 1);
            torusIndices.push_back(first + 1);
        }
    }

    glGenVertexArrays(1, &torusVAO);
    glGenBuffers(1, &torusVBO);
    glGenBuffers(1, &torusEBO);

    glBindVertexArray(torusVAO);

    glBindBuffer(GL_ARRAY_BUFFER, torusVBO);
    glBufferData(GL_ARRAY_BUFFER, torusVertices.size() * sizeof(float), &torusVertices[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, torusEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, torusIndices.size() * sizeof(unsigned int), &torusIndices[0], GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}
void SceneManager::renderTorus() {
    glBindVertexArray(torusVAO);
    glDrawElements(GL_TRIANGLES, 6 * 30 * 30, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}


void SceneManager::createNet() {
    float vertices[] = {
        -0.1f, -0.1f, -0.1f,  0.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         0.1f, -0.1f, -0.1f,  0.0f, 0.0f, 0.0f,  1.0f, 0.0f,
         0.1f, -0.3f, -0.1f,  0.0f, 0.0f, 0.0f,   1.0f, 1.0f,
        -0.1f, -0.3f, -0.1f,  0.0f, 0.0f, 0.0f,  0.0f, 1.0f,

        -0.1f, -0.1f, -0.3f,  0.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         0.1f, -0.1f, -0.3f,  0.0f, 0.0f, 0.0f,  1.0f, 0.0f,
         0.1f, -0.3f, -0.3f,  0.0f, 0.0f, 0.0f,   1.0f, 1.0f,
        -0.1f, -0.3f, -0.3f,  0.0f, 0.0f, 0.0f,  0.0f, 1.0f,
    };

    unsigned int indices[] = {
        0, 1, 2, 2, 3, 0,
        4, 5, 6, 6, 7, 4,
        0, 1, 5, 5, 4, 0,
        1, 2, 6, 6, 5, 1,
        2, 3, 7, 7, 6, 2,
        3, 0, 4, 4, 7, 3
    };

    glGenVertexArrays(1, &netVAO);
    glGenBuffers(1, &netVBO);
    glGenBuffers(1, &netEBO);

    glBindVertexArray(netVAO);

    glBindBuffer(GL_ARRAY_BUFFER, netVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, netEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);
}

void SceneManager::renderNet() {
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, netTexture);
    glBindVertexArray(netVAO);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void SceneManager::createHalfTorus() {
    const float majorRadius = 3.0f;
    const float minorRadius = 0.1f;

    std::vector<float> torusVertices;
    std::vector<unsigned int> torusIndices;

    for (int i = 0; i <= majorSegments / 2; ++i) {
        for (int j = 0; j <= minorSegments; ++j) {
            float theta = glm::pi<float>() * float(i) / float(majorSegments);
            float phi = 2.0f * glm::pi<float>() * float(j) / float(minorSegments);

            float x = (majorRadius + minorRadius * cos(phi)) * cos(theta);
            float y = (majorRadius + minorRadius * cos(phi)) * sin(theta);
            float z = minorRadius * sin(phi);

            float u = (float)i / (float)(majorSegments / 2);
            float v = (float)j / (float)minorSegments;

            torusVertices.push_back(x);
            torusVertices.push_back(y);
            torusVertices.push_back(z);
            torusVertices.push_back(u);
            torusVertices.push_back(v);
        }
    }

    for (int i = 0; i < majorSegments / 2; ++i) {
        for (int j = 0; j < minorSegments; ++j) {
            int first = (i * (minorSegments + 1)) + j;
            int second = first + minorSegments + 1;

            torusIndices.push_back(first);
            torusIndices.push_back(second);
            torusIndices.push_back(first + 1);

            torusIndices.push_back(second);
            torusIndices.push_back(second + 1);
            torusIndices.push_back(first + 1);
        }
    }

    glGenVertexArrays(1, &halfTorusVAO);
    glGenBuffers(1, &halfTorusVBO);
    glGenBuffers(1, &halfTorusEBO);

    glBindVertexArray(halfTorusVAO);

    glBindBuffer(GL_ARRAY_BUFFER, halfTorusVBO);
    glBufferData(GL_ARRAY_BUFFER, torusVertices.size() * sizeof(float), &torusVertices[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, halfTorusEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, torusIndices.size() * sizeof(unsigned int), &torusIndices[0], GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

void SceneManager::renderHalfTorus() {
    glBindVertexArray(halfTorusVAO);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, halfTorusTexture);
    glDrawElements(GL_TRIANGLES, 6 * (majorSegments / 2) * minorSegments, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void SceneManager::createHoopBox() {
    float boxVertices[] = {
        -0.5f, 0.0f,  0.5f,  
         0.5f, 0.0f,  0.5f,  
         0.5f, 0.0f, -0.5f,  
        -0.5f, 0.0f, -0.5f, 
    };

    glGenVertexArrays(1, &boxVAO);
    glGenBuffers(1, &boxVBO);

    glBindVertexArray(boxVAO);

    glBindBuffer(GL_ARRAY_BUFFER, boxVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(boxVertices), boxVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
}

void SceneManager::renderHoopBox() {
    glBindVertexArray(boxVAO);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, boxTexture);
    glDrawArrays(GL_LINES, 0, 4);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
    glLineWidth(10.0f);
}

void SceneManager::createHoopBox2() {
    float boxVertices[] = {
        -0.5f, 0.0f,  0.5f,
         0.5f, 0.0f,  0.5f,
         0.5f, 0.0f, -0.5f,
        -0.5f, 0.0f, -0.5f,
    };

    glGenVertexArrays(1, &boxVAO);
    glGenBuffers(1, &boxVBO);

    glBindVertexArray(boxVAO);

    glBindBuffer(GL_ARRAY_BUFFER, boxVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(boxVertices), boxVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
}

void SceneManager::renderHoopBox2() {
    glBindVertexArray(boxVAO);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, boxTexture);
    glDrawArrays(GL_LINES, 0, 4);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
    glLineWidth(10.0f);
}

