#ifndef SCENEMANAGER_H
#define SCENEMANAGER_H

#include <GL/glew.h>
#include <string>

class SceneManager {
public:
    SceneManager(GLuint shaderProgram);
    ~SceneManager();

    void renderGroundPlane();
    void renderCylinder();
    void renderBackboard();
    void renderTorus();
    void renderNet();
    void renderHalfTorus();
    void renderHoopBox();
    void renderHoopBox2();

private:
    void createGroundPlane();
    void createCylinder();
    void createBackboard();
    void createHalfTorus ();
    void createTorus();
    void createNet();
    void createHoopBox();
    void createHoopBox2();

    unsigned int loadTexture(const std::string& path);

    GLuint shaderProgram;

    GLuint groundVAO, groundVBO, groundEBO;
    GLuint groundTexture;

    GLuint cylinderVAO, cylinderVBO, cylinderEBO;
    GLuint cylinderTexture;

    GLuint backboardVAO, backboardVBO, backboardEBO;
    GLuint backboardTexture;

    GLuint torusVAO, torusVBO, torusEBO;
    GLuint torusTexture;

    GLuint netVAO, netVBO, netEBO;
    GLuint netTexture;

    GLuint halfTorusVAO, halfTorusVBO, halfTorusEBO;
    GLuint halfTorusTexture;
    static constexpr int majorSegments = 30;
    static constexpr int minorSegments = 30;

    GLuint boxVAO, boxVBO, boxEBO;
    GLuint boxTexture;
};

#endif
