#include "ViewManager.h"
#include <glm/gtc/matrix_transform.hpp>

ViewManager::ViewManager()
    : position(glm::vec3(0.0f, 0.0f, 3.0f)),
    target(glm::vec3(0.0f, 0.0f, 0.0f)),
    up(glm::vec3(0.0f, 1.0f, 0.0f)) {}

glm::mat4 ViewManager::getViewMatrix() const {
    return glm::lookAt(position, target, up);
}

glm::mat4 ViewManager::getProjectionMatrix(int width, int height) const {
    return glm::perspective(glm::radians(45.0f), (float)width / (float)height, 0.1f, 100.0f);
}
