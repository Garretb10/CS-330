#ifndef VIEWMANAGER_H
#define VIEWMANAGER_H

#include <glm/glm.hpp>

class ViewManager {
public:
    ViewManager();
    glm::mat4 getViewMatrix() const;
    glm::mat4 getProjectionMatrix(int width, int height) const;

private:
    glm::vec3 position;
    glm::vec3 target;
    glm::vec3 up;
};

#endif
